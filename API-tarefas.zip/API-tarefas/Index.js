//requerer/chamar o express
const bodyParser= require('body-parser');
const express= require('express');
const cors= require('cors')

//inicializar o app
const app= express()
const PORT=3000;

app.use(bodyParser.json())

let tarefas=[
 {id:1, descricao:"Estudar o NodeJs", completed:false},
 {id:2, descricao:"Criar API com Express", completed:false}
];

app.get('/index', (req,res) => {
 res.json("tarefas")
})

app.post ('/tarefas', (req, res)=>{
const {descricao}= req.body;

if (!descricao){
return removeEventListener.status(400).json({ error:"descrição obrigatoria"})
}

const novaTarefa ={
id: novaTarefa = tarefas.length + 1, // indica quantas tarefas existem na lista no momento.
descricao: descricao
};
tarefas.push(novaTarefa)//enviando as notificações
res.status(201).json(novaTarefa)
});

//rota para editar uma tarefa existente
app.put('/tarefas/:id', (req, res) =>{
const {id}= req.params;
const {descricao}= req.body

const tarefa= tarefas.find(t => t.id === parseInt(id))

if (!tarefa){
return res.status(404).json({ error: 'tarefa não encontrada'})
}

tarefa.descricao= descricao || tarefa.descricao
res.json(tarefa)
})

app.delete('/tarefa/id', (req,res) =>{
    const {id} = req.params
    const index= tarefas.findIndex(t => t.id === parseInt(id));

    if (index === -1){
    return res.status(404).json({ error: "Tarefa não encontrada"})
    }

    tarefas.splice(index,1);
    res.status(204).send()
})

//iniciando o servidor 
app.listen(port, () => {
console.log ('servidor rodando na porta', $(port));
});




